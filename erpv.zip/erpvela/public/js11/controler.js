/**
 *
 * Responsive website using AngularJS
 * http://www.script-tutorials.com/responsive-website-using-angularjs/
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2013, Script Tutorials
 * http://www.script-tutorials.com/
 */

'use strict';

// optional controllers
function HomeCtrl($scope, $http) {
}
function AboutCtrl($scope, $http, $timeout) {
}
function DoctorCtrl($scope, $http, $timeout) {
}
function AppoCtrl($scope, $http, $timeout) {
}
function BlogCtrl($scope, $http, $timeout) {
}
function ContactCtrl($scope, $http, $timeout) {
}
function TermsCtrl($scope, $http, $timeout) {
}
function PrivacyCtrl($scope, $http, $timeout) {
}
