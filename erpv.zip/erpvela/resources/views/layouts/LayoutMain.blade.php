<!doctype html>
<html>
<head>
</head>
<body>


    
        @include('includes.mainheader')
    



            @yield('content')

    

    <footer class="row">
        @include('includes.mainfooter')
    </footer>

</body>
</html>

