<!doctype html>
<html>
<head>
</head>
<body>


    
        @include('includes.header')
    



            @yield('content')

    

    <footer class="row">
        @include('includes.footer')
    </footer>

</body>
</html>

