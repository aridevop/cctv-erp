<!doctype html>
<html>
<head>
</head>
<body>


    
        @include('includes.header1')
    



            @yield('content')

    

    <footer class="row">
        @include('includes.footer')
    </footer>

</body>
</html>

