    
       <?php $__env->startSection('content'); ?>
       <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Terms and conditions</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <h2>Add terms and conditions</h2>
<form name="frm" action="<?php echo e(route('termins')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
      <label for="title">Term Title:</label>
      <input type="text" class="form-control" id="title" name="tmt">
    </div>
    <div class="form-group">
      <label for="title">Term Description:</label>
      <textarea class="form-control" id="summernote" name="tmd" rows="18">
          </textarea>
    </div>
    
    
    
    <input type="submit" name="sub" class="btn btn-success" value="Submit">
  </form>

            <!-- /.row -->
                       <!-- /.row -->
                

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.LayoutMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>